hMap: human labeled map
iMap: result of Itti's method
sMap: result of Spectral Residual
in: input images